<?php
require '../mainconfig.php';
require '../lib/header.php';
?>
						<div class="row">
							<div class="col-lg-12">
								<div class="card-box">
									<h4 class="m-t-0 m-b-30 header-title"><i class="fa fa-file"></i> What's New?</h4>
                                    <ul>
                                        <li>System Update, Insha Allah Maintained</li>
                                        <li>Improvement in website design</li>
                                        <li><b>Users:</b> Orders/Month Graph.</li>
                                        <li><b>Admin:</b> Profit Data/Deposit Graph, Services, Orders.</li>
                                        <li>Now available Automatic Deposit, All Operators for Credit. And BCA/BNI for Bank.</li>
                                        <li><b>#Notes :</b> The services we provide include full support & updates, if you have any problems or need help, you can contact us via the existing contact.</li>
                                    </ul>
								</div>
							</div>
						</div>
<?php
require '../lib/footer.php';
?>